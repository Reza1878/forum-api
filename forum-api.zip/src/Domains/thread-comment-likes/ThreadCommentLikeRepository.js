/* eslint-disable no-unused-vars */
/* eslint-disable class-methods-use-this */
class ThreadCommentLikeRepository {
  async addThreadCommentLike(payload) {
    throw new Error('THREAD_COMMENT_LIKE_REPOSITORY.METHOD_NOT_IMPLEMENTED');
  }

  async deleteThreadCommentLike(payload) {
    throw new Error('THREAD_COMMENT_LIKE_REPOSITORY.METHOD_NOT_IMPLEMENTED');
  }

  async verifyCommentLikes(payload) {
    throw new Error('THREAD_COMMENT_LIKE_REPOSITORY.METHOD_NOT_IMPLEMENTED');
  }
}

module.exports = ThreadCommentLikeRepository;
